var controller = require('../controllers/primaryController.js')

module.exports = function (app) {
  // Root Route
  app.get('/', function (req, res) {
    controller.index(req, res)
  })
  app.get('/', function (req, res) {
    controller.index(req, res)
  })
  app.get('/new/:name', function (req, res) {
    controller.add(req, res)
  })
  app.get('/remove/:name', function (req, res) {
    controller.remove(req, res)
  })
  app.get('/:name', function (req, res) {
    controller.get(req, res)
  })
}
