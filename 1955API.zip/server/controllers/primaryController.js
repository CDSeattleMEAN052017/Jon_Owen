var mongoose = require('mongoose')
var Person = mongoose.model('Person')

module.exports = {
  index: function (req, res) {
    Person.find({}, function (err, person) {
      if (err) {
        console.log('Error')
        res.redirect('/')
      } else {
        res.json(person)
      }
    })
  },
  add: function (req, res) {
    var newPerson = new Person({name: req.params.name})
    newPerson.save({}, function (err, data) {
      if (err) {
        console.log('Unable to save name')
      } else {
        console.log(`Name (${req.params.name}) saved`)
      }
    })
    res.redirect('/')
  },
  remove: function (req, res) {
    Person.remove({name: req.params.name}, function (err) {
      if (err) {
        console.log('Unable to remove')
      } else {
        console.log('Name removed')
      }
    })
    res.redirect('/')
  },
  get: function (req, res) {
    Person.findOne({name: req.params.name}, function (err, person) {
      if (err) {
        console.log(`Unable to find ${req.params.name}`)
        res.redirect('/')
      } else {
        console.log('Name found')
        res.json(person)
      }
    })
  }
}
