import { Component, OnInit } from '@angular/core';
import { NoteService } from './note.service';
import { Note } from './note';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {

  listOfNotes: Array<Note>
  selectedNote: Note = new Note

  constructor(private _noteService: NoteService) {
    this.listOfNotes = this._noteService.getAll()
  }

  ngOnInit() {
  }

  newNote (note: Note): void {
    this._noteService.addNote(note)
  }
  removeNote (index: number): void {
    this._noteService.removeNote(index)
  }
  editNote (index: number) {
    this.selectedNote = this.listOfNotes[index]
  }
  saveNote (note: Note) {
    this._noteService.saveEditNote(this.selectedNote, note)
    this.selectedNote = new Note
  }
}
