import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { Note } from '../note';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  @Input() editSend: Note
  @Output() editReceive = new EventEmitter()
  editedNote: Note = new Note
  constructor() { }

  ngOnInit() {
  }
  ngOnChanges () {
    this.editedNote = {note: this.editSend.note, createdAt: this.editSend.createdAt, updatedAt: new Date()}
  }
  editNote () {
    this.editReceive.emit(this.editedNote)
  }
}
