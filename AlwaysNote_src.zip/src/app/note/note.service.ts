import { Injectable } from '@angular/core';
import { Note } from './note';

@Injectable()
export class NoteService {

  savedNotes: Array<any> =[
    {note: 'First Note...', createdAt: new Date(), updatedAt: new Date()}
  ]

  constructor () { }
  getAll (): Array<Note> {
    return this.savedNotes
  }
  addNote (newNote): void {
    this.savedNotes.push(newNote)
  }
  removeNote (index): void {
    this.savedNotes.splice(index, 1)
  }
  saveEditNote (orig, change): void {
    for (let key in orig ) {
      orig[key] = change[key]
    }
  }
}
