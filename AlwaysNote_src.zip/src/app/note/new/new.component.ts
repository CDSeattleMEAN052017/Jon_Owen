import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Note } from '../note'

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  @Output() newReceive = new EventEmitter()
  newNote: Note = new Note
  toSave: Note
  constructor() { }

  ngOnInit() {
  }
  addNote() {
    this.toSave = {note: this.newNote.note, createdAt: new Date(), updatedAt: new Date()}
    this.newReceive.emit(this.toSave)
    this.newNote = new Note
  }
}
