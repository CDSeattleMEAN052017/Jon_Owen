import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { NoteComponent } from './note/note.component';
import { NewComponent } from './note/new/new.component';
import { ListComponent } from './note/list/list.component';
import { EditComponent } from './note/edit/edit.component';
import { NoteService } from './note/note.service'

@NgModule({
  declarations: [
    AppComponent,
    NoteComponent,
    NewComponent,
    ListComponent,
    EditComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [NoteService],
  bootstrap: [AppComponent]
})
export class AppModule { }
