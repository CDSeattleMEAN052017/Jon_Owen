var express = require('express')
var path = require('path')
var app = express()
var mongooseDb = require('mongoose')
var bodyParser = require('body-parser')

const PORT = 8000

app.use(bodyParser.urlencoded({extended: true}))
app.use(express.static(path.join(__dirname, '/static')))

app.set('views', path.join(__dirname, '/views'))
app.set('view engine', 'ejs')

const dbName = 'message_board'
const dbLocation = 'localhost'
const dbString = dbLocation + '/' + dbName

mongooseDb.connect(`mongodb://${dbString}`)
var Schema = mongooseDb.Schema
var messagesSchema = new mongooseDb.Schema({
  name: {type: String, required: true, minlength: 4},
  message: {type: String, required: true, minlength: 2},
  comments: [{type: Schema.Types.ObjectId, ref: 'Comment'}]
}, {timestamps: true})
var commentSchema = new mongooseDb.Schema({
  _message: {type: Schema.Types.ObjectId, ref: 'Message'},
  name: {type: String, required: true, minlength: 4},
  comment: {type: String, required: true, minlength: 2}
}, {timestamps: true})
mongooseDb.model('Message', messagesSchema)
var Message = mongooseDb.model('Message')
mongooseDb.model('Comment', commentSchema)
var Comment = mongooseDb.model('Comment')

// Root route
app.get('/', function (req, res) {
  var returnData = {title: 'The Dojo Message Board'}
  Message.find({})
  .sort({createdAt: -1})
  .populate({path: 'comments', options: {sort: {'createdAt': -1}}})
  .exec(function (err, data) {
    if (err) {
      returnData.errors = 'Something went wrong'
    } else {
      returnData.messages = data
      console.log(data)
    }
    // console.log(returnData)
    res.render('index', returnData)
  })
})
app.post('/newMessage', function (req, res) {
  console.log(req)
  var newMessage = new Message({name: req.body.name, message: req.body.message})
  newMessage.save({}, function (err, data) {
    if (err) {
      console.log('Error saving message')
    } else {
      console.log('Message saved')
    }
    res.redirect('/')
  })
})
app.post('/newComment', function (req, res) {
  // code to add db goes here!
  Message.findOne({_id: req.body.msgId}, function (err, message) {
    var newComment = new Comment({name: req.body.name, comment: req.body.comment, _message: message._id})
    newComment.save({}, function (err) {
      message.comments.push(newComment)
      message.save(function (err) {
        if (err) {
          console.log('Error saving comment')
        } else {
          console.log('Comment Saved')
        }
      })
    })
    res.redirect('/')
  })
})

app.listen(PORT, function () {
  console.log(`listening on port ${PORT}`)
})
