export class Task {
  desc: string
  done: boolean

  constructor () {
    this.done = false
  }
}
