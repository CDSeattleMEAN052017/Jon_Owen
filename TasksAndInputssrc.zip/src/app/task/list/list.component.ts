import { Component, OnInit } from '@angular/core';
import { Task } from "./task";

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  myTasks: Task[]
  constructor() { }
  updateToTaskParent (index) {
    this.myTasks[index.index].done = (this.myTasks[index.index].done)? false : true
  }
  ngOnInit() {
    this.myTasks = [
      {desc: 'First Task', done: false},
      {desc: 'Second Task', done: true},
      {desc: 'Third Task', done: false}
    ];
  }

}
