import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent {
  @Input() tasks;
  @Output() updateFromTaskChild = new EventEmitter();
  constructor () {}

  changeState (index){
    this.updateFromTaskChild.emit({index})
  }
}
