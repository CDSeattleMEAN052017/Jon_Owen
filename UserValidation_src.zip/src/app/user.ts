export class User {
  firstName: string
  lastName: string
  email: string
  password: string
  passwordConf: string
  // state: string
  createdAt: Date

  constructor () {
    this.createdAt = new Date()
  }
}
