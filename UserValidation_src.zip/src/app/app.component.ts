import { Component, OnChanges } from '@angular/core';
import {NgForm} from '@angular/forms';
import { User } from './user'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  user:User = new User()
  title = 'app works!';
  validationMessages = {
    'firstName': {
      'required': 'Name is required'
    }
  }
  constructor () { }

  submitUser(newUser: NgForm) {
    console.log(newUser)
  }
}
