var express = require('express')
var path = require('path')
var app = express()
var mongoose = require('mongoose')
var bodyParser = require('body-parser')

const PORT = 8000

const dbName = 'quoting_dojo'
const dbLocation = 'localhost'
const dbString = dbLocation + '/' + dbName

app.use(bodyParser.urlencoded({extended: true}))
app.use(express.static(path.join(__dirname, '/static')))

app.set('views', path.join(__dirname, '/views'))
app.set('view engine', 'ejs')

mongoose.connect(`mongodb://${dbString}`)
var QuoteSchema = new mongoose.Schema({
  name: {type: String},
  quote: {type: String}
}, {timestamps: true})
mongoose.model('Quote', QuoteSchema)
var Quote = mongoose.model('Quote')

// Root route
app.get('/', function (req, res) {
  res.render('index')
})
// From successful form submission
app.get('/success', function (req, res) {
  Quote.find({}, [], {sort: {createdAt: -1}}, function (err, quotes) {
    if (err) {
      console.log('Unable to retrive data')
      res.redirect('/')
    } else {
      res.render('quotes', {quotes: quotes})
    }
  })
})
app.post('/quotes', function (req, res) {
  // code to add db goes here!
  var newQuote = new Quote({name: req.body.name, quote: req.body.quote})
  newQuote.save({}, function (err, quote) {
    if (err) {
      console.log('Unable to save data')
      res.redirect('/')
    } else {
      console.log('Data saved')
      res.redirect('/success')
    }
  })
})

app.listen(PORT, function () {
  console.log(`listening on port ${PORT}`)
})
